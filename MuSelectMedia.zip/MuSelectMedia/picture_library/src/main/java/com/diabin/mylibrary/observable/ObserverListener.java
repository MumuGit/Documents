package com.diabin.mylibrary.observable;

import com.diabin.mylibrary.entity.LocalMedia;
import com.diabin.mylibrary.entity.LocalMediaFolder;

import java.util.List;

/**
 * Created by mu on 2017/12/12.
 */

public interface ObserverListener {
    void observerUpFoldersData(List<LocalMediaFolder> folders);

    void observerUpSelectsData(List<LocalMedia> selectMedias);
}
