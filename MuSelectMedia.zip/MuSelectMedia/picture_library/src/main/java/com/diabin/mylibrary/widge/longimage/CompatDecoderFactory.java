package com.diabin.mylibrary.widge.longimage;

import android.support.annotation.NonNull;

/**
 * Created by mu on 2017/12/13.
 */

public class CompatDecoderFactory<T> implements DecoderFactory<T> {
    private Class<? extends T> clazz;

    public CompatDecoderFactory(@NonNull Class<? extends T> clazz) {
        this.clazz = clazz;
    }

    @Override
    public T make() throws IllegalAccessException, InstantiationException {
        return clazz.newInstance();
    }
}

