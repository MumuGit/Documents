package com.diabin.mylibrary.observable;

/**
 * Created by mu on 2017/12/12.
 */

public interface SubjectListener {
    void add(ObserverListener observerListener);

    void remove(ObserverListener observerListener);
}
