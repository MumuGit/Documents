package com.diabin.mylibrary;

import android.support.v4.content.FileProvider;

/**
 * Created by Mankin on 2017/8/29.
 */

public class PictureFileProvider extends FileProvider {


}
