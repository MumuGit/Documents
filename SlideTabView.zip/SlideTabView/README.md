SlideTabView
===================================  
滑动tab标签

演示效果
-----------------------------------
![image](https://github.com/dongxiaoshuai/SlideTabView/blob/master/app/src/main/res/drawable/GIF.gif)   

使用方法
-----------------------------------
###在xml文件中：

	<com.lcworld.tab.SlideTabView
	 android:id="@+id/tab"
      android:layout_width="match_parent"
      android:layout_height="wrap_content" />
